const express    = require('express');
const app        = express();
app.use(express.json());

const { tarefaController, usuarioController } = require('./src/infrastructure/config/container');
const tarefaRoutes  = require('./src/infrastructure/http/routes/tarefa/tarefaRoutes');
const usuarioRoutes = require('./src/infrastructure/http/routes/usuario/usuarioRoutes');

app.use('/tarefas',  tarefaRoutes(tarefaController));
app.use('/usuarios', usuarioRoutes(usuarioController));

module.exports = app;
